package com.cdslab.question;

import org.apache.uima.analysis_engine.AnalysisEngineDescription;
import org.apache.uima.collection.CollectionReaderDescription;
import static org.apache.uima.fit.pipeline.SimplePipeline.runPipeline;

import cz.brmlab.yodaqa.io.interactive.InteractiveAnswerPrinter;
import cz.brmlab.yodaqa.io.interactive.InteractiveQuestionReader;

import static org.apache.uima.fit.factory.AnalysisEngineFactory.createEngineDescription;
import static org.apache.uima.fit.factory.CollectionReaderFactory.createReaderDescription;


/* FIXME: Massive code duplication of YodaQA_Interactive and YodaQA_GS.
 * Let's abstract out the processing pipeline later. */

public class YodaQA_Interactive {
	public static void main(String[] args) throws Exception {
		
		CollectionReaderDescription reader = createReaderDescription(
				InteractiveQuestionReader.class,
				InteractiveQuestionReader.PARAM_LANGUAGE, "en");

		AnalysisEngineDescription pipeline = YodaQA.createEngineDescription();

		AnalysisEngineDescription printer = createEngineDescription(
				InteractiveAnswerPrinter.class);

		/*AnalysisEngineDescription pipeline = YodaQA.createEngineDescription();
		System.out.println(pipeline);*/

		/*AnalysisEngineDescription printer = createEngineDescription(
				InteractiveAnswerPrinter.class);

		ParallelEngineFactory.registerFactory(); 
		 XXX: Later, we will want to create an actual flow
		 * to support scaleout. */
		runPipeline(reader,
				pipeline,
				printer);
	}
}
