package com.cdslab.question;

import org.apache.uima.analysis_engine.AnalysisEngineDescription;
import org.apache.uima.cas.CAS;
import org.apache.uima.fit.factory.AggregateBuilder;
import org.apache.uima.fit.factory.AnalysisEngineFactory;
import org.apache.uima.fit.factory.FlowControllerFactory;
import org.apache.uima.flow.impl.FixedFlowController;
import org.apache.uima.resource.ResourceInitializationException;

import com.cdslab.question.QuestionAnalysisAE;


public class YodaQA  {


	public static AnalysisEngineDescription createEngineDescription() throws ResourceInitializationException {

		AggregateBuilder builder = new AggregateBuilder();

		boolean outputsNewCASes = buildPipeline(builder);

		builder.setFlowControllerDescription(
				FlowControllerFactory.createFlowControllerDescription(
						FixedFlowController.class,
						FixedFlowController.PARAM_ACTION_AFTER_CAS_MULTIPLIER, "drop"));

		AnalysisEngineDescription aed = builder.createAggregateDescription();
		aed.getAnalysisEngineMetaData().setName("com.cdslab.pipeline.YodaQA");
		if (outputsNewCASes)
			aed.getAnalysisEngineMetaData().getOperationalProperties().setOutputsNewCASes(true);
		return aed;
	}

	/** Build a multi-phase pipeline, possibly skipping some phases
	 * based on property setting. Returns whether the pipeline outputs
	 * new CASes. */
	protected static boolean buildPipeline(AggregateBuilder builder) throws ResourceInitializationException {
		boolean outputsNewCASes = false;

		AnalysisEngineDescription questionAnalysis = QuestionAnalysisAE.createEngineDescription();
		builder.add(questionAnalysis);


		return outputsNewCASes;
	}



}
