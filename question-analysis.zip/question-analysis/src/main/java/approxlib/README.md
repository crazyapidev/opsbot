approxlib has been created by Nikolaus Augsten, but the version available
for download at http://www.cosy.sbg.ac.at/~augsten/src/ has some differences
from the one available here, which has been obtained from the PARMA github
repo https://github.com/hltcoe/parma and sadly (like the copy in Jacana)
contains no further genesis information (but it does contain the BSD licence
headers).

TODO: This should live separate in its own repository and be included as
a Maven artifact.  It is entirely independent from the YodaQA code, or even
UIMA.
