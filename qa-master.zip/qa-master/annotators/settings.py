# coding: utf-8

"""
Settings.
"""

NLP_ENGINE =  "spacy" # "spacy" "nltk"

TOKENIZER = 'WHITE_SPACE_TOKENIZER'

# NLTK config
NLTK_DATA_PATH = ['/home/ubuntu/nltk_data','C:/nltk_data',"D:/nltk_data"]  # List of paths with NLTK data

# Encoding config
DEFAULT_ENCODING = "utf-8"
