# -*- coding: utf-8 -*-
"""
Abstract Base Classes(ABC) for NLP Engines
"""
from abc import abstractmethod
from annotators.datatypes import Word,Entity
from spacy import en
import nltk
from nltk.tokenize import PunktSentenceTokenizer
from nltk import WordPunctTokenizer,pos_tag
from nltk import corpus
# from _pyio import __metaclass__

_penn_to_morphy_tag = {}

def penn_to_morphy_tag(tag):
    for penn, morphy in _penn_to_morphy_tag.iteritems():
        if tag.startswith(penn):
            return morphy
    return None

##############################################
# ABC for NLP Library
##############################################

class NLPLibrary (object):
#     __metaclass__ = ABCMeta
    
    @abstractmethod
    def sentencer(self,text):
        """ Sentence Segmentation """
        raise NotImplemented
    
    @abstractmethod
    def tokenization(self,text):
        """ Implement tokenization Logic """
        raise NotImplemented
    
    @abstractmethod
    def tag_pos_and_lemma(self,tokens):
        """ word = token + POS + Lemma """
        raise NotImplemented
    
    @abstractmethod
    def tag_generic_entities(self,text):
        raise NotImplemented
    
#     @abstractmethod
#     def lemma(self,token):
#         """Implement Lemmatization """
#         raise NotImplemented



###############################################
# NLTK subclasses
###############################################

class NLTKLibrary(NLPLibrary):
    
    def __init__(self):
        if not nltk.data.path:
            raise EnvironmentError('nltk data path not set')
        
        self.sentencer_segmenter = PunktSentenceTokenizer()
        self.tokenizer = WordPunctTokenizer()
    
    def sentencer(self,text):
        """ 
        sentence segmenter  
        """
        for i, j in self.sentencer_segmenter.span_tokenize(text):
            yield i, j, text[i:j]
    
    def tokenization(self,text):
        """ 
        Tokenize a text into a sequence of alphabetic and
        non-alphabetic characters, using the regexp ``\w+|[^\w\s]+``. 
        """
        tokenAnnotations=[]
        
        for i,j in self.tokenizer.span_tokenize(text):
            tokenAnnotations.append(text[i:j])
        
        return tokenAnnotations
    
    def tag_pos_and_lemma(self,tokens):
        """ POS Tagging and Lemma """
        _penn_to_morphy_tag = {}
        
        if not _penn_to_morphy_tag:
            _penn_to_morphy_tag = {
                u'NN': nltk.corpus.reader.wordnet.NOUN,
                u'JJ': nltk.corpus.reader.wordnet.ADJ,
                u'VB': nltk.corpus.reader.wordnet.VERB,
                u'RB': nltk.corpus.reader.wordnet.ADV,
            }

        tags = nltk.pos_tag(tokens) #token for (token,(start,end)) in
    
        words = []
        i=0
        for text, pos in tags:
            word = Word(text) # , tokens[i][1],tokens = [(token_text,(start,end))]
            # Eliminates stuff like JJ|CC
            # decode ascii because they are the penn-like POS tags (are ascii).
            word.pos = pos.split("|")[0]
            
            if word.pos in _penn_to_morphy_tag.keys():
                mtag = _penn_to_morphy_tag[word.pos]
            else:
                mtag = nltk.corpus.reader.wordnet.NOUN
    
            
            lemma = corpus.wordnet._morphy(word.token, pos=mtag)
            if len(lemma)==0:
                word.lemma = word.token.lower()
            else:
                word.lemma = lemma[0]
    
            words.append(word)
            i+=1
        return words
    
    def tag_generic_entities(self,text):
        pass
    
#     def lemma(self,token):
#         """Implement Lemmatization """
#         pass


###############################################
# Spacy NLP Engine
###############################################

class SpacyLibrary(NLPLibrary):
    
    def __init__(self):
        self.nlp =  en.English()
    
    def sentencer(self,text):
        """ Sentence Segmentation returns list of sentences for given input passage"""
        
        doc = self.nlp(text)
        
        for sent in doc.sents:
            yield sent.start_char,sent.end_char,text[sent.start_char:sent.end_char]
    
    def tokenization(self,text):
        """
        Tokenize a text into a sequence of alphabetic and
        non-alphabetic characters, using the regexp ``\w+|[^\w\s]+``. 
        """
        
        doc = self.nlp(text)
        
        tokenAnnotations=[]
        
        for token in doc:
            tokenAnnotations.append(token.text)
        
        return tokenAnnotations
    
    def tag_pos_and_lemma(self,text):
        """ POS Tagging """
        
        doc = self.nlp(text)
        words = []
        
        for token in doc:
            word = Word(token.text)
            word.pos = token.tag_
            word.lemma = token.lemma_
            words.append(word)
        
        return words
    
    def tag_generic_entities(self,text):
        
        doc = self.nlp(text)
        entities = []
        for ent in doc.ents:
            entities.append(Entity(ent.text,ent.label_))
    
        return entities
#     def lemma(self,token):
#         """Implement Lemmatization """
#         pass
    