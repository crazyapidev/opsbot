"""
Classify question type

"""
