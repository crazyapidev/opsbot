# -*- coding: utf-8 -*-
'''
Created on Feb 20, 2018

@author: 420169
'''
from annotators.datatypes import Document
from annotators.pipeline import AnnotatorPipeline
from annotators.sentencer import SentenceAnnotator
from annotators.tokenizer import TokenAnnotator
from annotators.word import WordAnnotator
from annotators.entity_tagger import EntityTagger

def tag_entity():
    
    paragraph = "To the south of northern plains lies the Peninsular plateau." + \
     "It is triangular in shape. The relief is highly uneven." + \
    "This is a region with numerous hill ranges and valleys. Aravali hills, one of the oldest ranges of the world, border it on the north-west side." + \
     "The Vindhyas and the Satpuras are the important ranges."+ \
     "The rivers Narmada and Tapi flow through these ranges." + \
     "These are west-flowing rivers that drain into the Arabian Sea." +\
     "The Western Ghats or Sahyadris border the plateau in the west and the Eastern Ghats provide the eastern boundary."+\
     "While the Western Ghats are almost continuous, the Eastern Ghats are broken and uneven."+\
     "The plateau is rich in minerals like coal and iron-ore."
       
    doc = Document(id="sample",text=lambda:paragraph)
          
    pipeline=AnnotatorPipeline([SentenceAnnotator(),TokenAnnotator(),WordAnnotator(),EntityTagger()]) # ,TokenAnnotator(),WordAnnotator()
    pipeline.process(doc)
    for entity in doc.entities:
        print(entity.words,entity.entity_type)
  
tag_entity()

# from spacy import en
# 
# nlp = en.English()
# doc = nlp("Apple is looking at buying U.K. startup for $1 billion")
# for token in doc:
#     print(token.text, token.lemma_, token.pos_, token.tag_, token.dep_,
#           token.shape_, token.is_alpha, token.is_stop,token.text_with_ws)



