# coding: utf-8

"""
Tagging using SPACY.
"""

# Requiered data files are:
#   - "maxent_treebank_pos_tagger" in Models
#   - "wordnet" in Corpora

import spacy
from nlquepy.tagger import Word
from nlquepy.encodingpolicy import assert_valid_encoding
from spacy.en import English
from spacy.tokens import doc
import logging
logger = logging.getLogger(__name__)

class WhitespaceTokenizer(object):
    def __init__(self, nlp):
        self.vocab = nlp.vocab

    def __call__(self, text):
        words = text.split(' ')
        # All tokens 'own' a subsequent space character in this tokenizer
        spaces = [True] * len(words)
        return doc(self.vocab, words=words, spaces=spaces)


def run_spacytagger(string, spacy_data_path=None):
    """
    Runs tagger on `string` and returns a list of
    :class:`quepy.tagger.Word` objects.
    """
    from nlquepy import settings
    assert_valid_encoding(string)
    logger.info("SPACY TAGGER - intialized")
    if spacy_data_path:
        tagger = English(path =spacy_data_path)
    else :
        tagger = English(path =settings.SPACY_DATA_PATH)
    # Recommended tokenizer doesn't handle non-ascii characters very well
    words = []
    if settings.TOKENIZER =="WHITE_SPACE_TOKENIZER":
        for word in string.split():
            doc = tagger(unicode(word))#[tagger(word) for word in string.split()]
            for w in doc:
                token = w.text
                pos = w.tag_
                lemma = w.lemma_
            word = Word(unicode(token))
            word.pos =pos
            word.lemma = lemma
            words.append(word)
    else :       
        tokens = tagger(string)#[tagger(word) for word in string.split()]
        for token in tokens:
            word = Word(unicode(token))
            word.pos =token.tag_
            word.lemma = token.lemma_
            if word.lemma is None:
                word.lemma = word.token.lower()
        words.append(word)
    return words
    
