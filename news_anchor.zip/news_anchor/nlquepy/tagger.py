# coding: utf-8

from news import settings
from nlquepy.encodingpolicy import assert_valid_encoding
import logging

logger = logging.getLogger("quepy.tagger")
PENN_TAGSET = set(u"$ `` '' ( ) , -- . : CC CD DT EX FW IN JJ JJR JJS LS MD "
                  "NN NNP NNPS NNS PDT POS PRP PRP$ RB RBR RBS RP SYM TO UH "
                  "VB VBD VBG VBN VBP VBZ WDT WP WP$ WRB".split())


class TaggingError(Exception):
    """
    Error parsing tagger's output.
    """
    pass


class Word(object):
    """
    Representation of a tagged word.
    Contains *token*, *lemma*, *pos tag* and optionally a *probability* of
    that tag.
    """
    _encoding_attrs = u"token lemma pos entity_id entity_type trans suggestion BIO".split()
    _attrs = _encoding_attrs + [u"prob"]

    def __init__(self, token, lemma=None, pos=None,entity_id=None,
                 entity_type=None,trans=None,suggestion=None,BIO=None,prob=None):
        
        self.lemma = lemma
        self.token = token
        self.pos = pos
        self.entity_id = entity_id
        self.entity_type = entity_type
        self.trans = trans
        self.suggestion=suggestion
        self.BIO = BIO
        self.prob = prob

    def __setattr__(self, name, value):
        if name in self._encoding_attrs and value is not None:
            assert_valid_encoding(value)
        object.__setattr__(self, name, value)

    def __unicode__(self):
        attrs = (getattr(self, name, u"-") for name in self._attrs)
        return u"|".join(str(x) for x in attrs)

    def __repr__(self):
        return unicode(self)


    

def pos_tagging():
    """
    Return a tagging function given some app settings.
    `Settings` is the settings module of an app.
    The returned value is a function that receives a unicode string and returns
    a list of `Word` instances.
    """
    from nlquepy.nltktagger import run_nltktagger
    # from nlquepy.spacytagger import run_spacytagger
    
    tagger_function = lambda x: (run_nltktagger(x, settings.NLTK_DATA_PATH) ) #if settings.TAGGER == "NLTK" 
                                 # else run_spacytagger(x, settings.SPACY_DATA_PATH))
    
    def wrapper(string):
        assert_valid_encoding(string)
        words = tagger_function(string)
        for word in words:
            if word.pos not in PENN_TAGSET:
                logger.warning("Tagger emmited a non-penn "
                               "POS tag {!r}".format(word.pos))
        return words
    return wrapper
    
    
def get_tagger():
    logger.info("Tagger Initialized")
#     from utilities.spell_checker import spellcheck
#     from entity_tagger import entity_tag
    pos_wrapper = pos_tagging()
    
    def text_tagger(string):
        word_list = pos_wrapper(unicode(string))
#         word_list = spellcheck(word_list)
#         words_updated = entity_tag.run_entity_tagger(word_list)
        return word_list
    
    return text_tagger

