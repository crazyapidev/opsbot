
from nlquepy.parsing import Lemma,Pos,Token,Entity,Lemmas,Tokens
from refo import Group, Plus, Question

"""Entities"""
place = Group(Entity("place"),"place")
location = Group(Entity("location"),"location")
date = Group(Entity("date"),"date")
units = Group(Entity("units"),"units")
person = Group((Entity("person")),"person")

""" noun_forms"""
noun = Pos("NN") 
noun_plural  =  Pos("NNS")
proper_noun  = Pos("NNP")
proper_noun_plural = Pos("NNPS")

"""Question_forms"""
which = Lemma("which")
when = Lemma("when")
what = Lemma("what")
how = Lemma("how")
why = Lemma("why")
who = Lemma('who')
   
""" verb_forms"""
auxilary_verb = Lemma("be")
verb     =  Pos("VB") 
verb_past = Pos("VBD")
verb_present_participle = Pos("VBG")
verb_past_participle =Pos("VBN")
    
""" noun_verb_modifers"""
adverb                 = Pos("RB")
adverb_comparative    = Pos("RBR")
adverb_superlative    = Pos("RBS")
adjective              = Pos("JJ")
adjective_comparative  = Pos("JJR")
adjective_superlative  = Pos("JJS")
    
""" connecting_words"""
conjunction            = Pos("CC")          #and,but,yet
preposition            = Pos("IN")          #from,in,over,on,of
to                     = Pos("TO")          #to
determiner             = Pos("DT")          #the
predeterminer          = Pos("PDT")
    
""" Miscellaneous"""
ls     =  Pos("LS")   # List Object
number = Pos("CD")
symbol = Pos("SYM")
foreign_word =Pos("FW")
    
"""
        Conjunction                               =          "CC" ,
        Number                                    =          "CD" ,
        Determiner                                =          "DT" ,
        Foreign_word                              =          "FW" ,
        Preposition                               =          "IN" ,
        Adjective                                 =          "JJ" ,
        Adjective_comparative                     =          "JJR",
        Adjective_superlative                     =          "JJS",
        List_item                                 =          "LS" ,
        Modal                                     =          "MD" ,
        Noun                                      =          "NN" ,
        Noun_plural                               =          "NNS",
        Proper_noun                               =          "NNP",
        Proper_noun_plural                        =          "NNPS",
        Predeterminer                             =          "PDT",
        Possessive_ending                         =          "POS",
        Personal_pronoun                          =          "PRP",
        Adverb                                    =          "RB" ,
        Adverb, comparative                       =          "RBR",
        Adverb, superlative                       =          "RBS",
        Particle                                  =          "RP" ,
        Symbol                                    =          "SYM",
        to                                        =          "TO" ,
        Interjection                              =          "UH" ,
        Verb                                      =          "VB" ,
        Verb_past                                 =          "VBD",
        Verb_present_participle                   =          "VBG",
        Verb_past_participle                      =          "VBN",
        Wh_determiner                             =          "WDT",
        Wh_pronoun                                =          "WP" ,
        Wh_adverb                                 =          "WRB"      
"""