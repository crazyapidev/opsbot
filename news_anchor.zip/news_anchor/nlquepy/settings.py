# coding: utf-8

"""
Settings.
"""

# Generated query language
LANGUAGE = "sparql"

# POS Tagger
# TAGGER = 'NLTK'
TAGGER = 'SPACY'

TOKENIZER = 'WHITE_SPACE_TOKENIZER'

# NLTK config
NLTK_DATA_PATH = ['/home/ubuntu/nltk_data','C:/nltk_data',"D:/nltk_data","/usr/local/share/nltk_data"]  # List of paths with NLTK data
SPACY_DATA_PATH = ["C:/Users/574967/Python27/Lib/site-packages/spacy/data/en-1.1.0"] # path for spacy tagger data

# Encoding config
DEFAULT_ENCODING = "utf-8"

""" Provide the list of taggers required """
# ENTITY_TAGGER = ["date","units","location","place"]
ENTITY_TAGGER = ["date","units","location","place","person"]

LOCATION_INDEX_NAME,LOCATION_DOC_TYPE = u"entity_location" ,u"location"
LOCATION_VALID_INDEX_NAME,LOCATION_VALID_DOC_TYPE = u"entity_location_valid",u"location"
PERSON_INDEX_NAME,PERSON_DOC_TYPE = u"entity_person",u"person"
EVENT_DATES_INDEX_NAME,EVENT_DATES_DOC_TYPE = u"event_dates",u"holidays"