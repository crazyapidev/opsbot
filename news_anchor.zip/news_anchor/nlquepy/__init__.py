# coding: utf-8

"""
Quepy converts Natural Language Question to database queries.
"""

VERSION = 0.2

import logging
from nlquepy.quepyapp import install, QuepyApp

def set_loglevel(level=logging.WARNING):
    logger = logging.getLogger("nlquepy")
    logger.setLevel(level)
