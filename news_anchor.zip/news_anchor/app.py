import os
import json
import logging
from flask import Flask
from flask import request
from news_qna.request_processor import process_request

logger = logging.getLogger(__name__)
app = Flask(__name__)

@app.route('/test',methods=['POST','GET'])
def test() :
    return "News Articles"

@app.route('/virtualnewsanchor', methods=['POST'])
def news_info():
    request_query = request.get_json(silent=True, force=True)
    logger.info("request : %s",request_query)
    response = process_request(request_query) 
    return response

    
if __name__ == '__main__' :
    port = int(os.getenv('PORT', 7700))
    print("Starting app on port "+ str(port))
    app.run(debug=False, port=port, host='0.0.0.0')
