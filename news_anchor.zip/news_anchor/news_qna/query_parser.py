# -*- coding: utf-8 -*-

from pyparsing import *
import re


class IntentTagger():
    
    TOPIC = "spanish soccer"
    READ = "read|say|tell|speak|show"
    REPEAT = "repeat|again"
    NEXT = "next|new"
    QUESTION = "who|what|which|when|where"
    PLURAL = Word("s") | Word("'s")
    
    INTENTS = ["read_article","question","search_articles"] #
    
    r_REPEAT = Regex(REPEAT)
    r_NEXT = Regex(NEXT)
    r_READ = Regex(READ)
    r_QUESTION = Regex(QUESTION)
    r_TOPIC=Regex(TOPIC)
                   
    def parse(self,query):
        topic = ''
        intent = self.identify_intent(query)
        topic = self.identify_entity(query,self.r_TOPIC, topic)
        query_parameters = {"query" : query,"intent" : intent,"topic":topic}
        return query_parameters
    
    
    def identify_intent(self,command):
        intent = ''
        for intent_type in self.INTENTS:
            for r in self.intents[intent_type]:
                tag = r.searchString(command.lower())
                if tag :
                    intent = intent_type
                    break
            if intent:
                break
        return intent
         
    def identify_entity(self,query,entity_rule,entity):
        tag = entity_rule.searchString(query.lower())
        if tag:
            entity = tag[0][0]
        return entity
    
    
    intents = {
                    
                    "read_article":[
                                          r_READ
                                           ],
                     "question":[
                                 r_QUESTION
                                 ],
                    "search_articles":[
                                      r_TOPIC 
                                       ]
                    }
                   


news_queries ="""Spanish Soccer
Can you read the article on Player of the Month Diego Costa?
Who was the La Liga player of the month for December?
""".splitlines()



  
# for query in news_queries:
#     print query,IntentTagger().parse(query)        
       

