import nlquepy
import logging 

logger = logging.getLogger(__name__)

class Answer():
    
    def __init__(self,question):
        self._question = question
     
    def get_answer_from_elastic_search(self):
        answer = "yet to be implemented"#get_answer_from_elasticsearch(self._question) 
        logger.info("answer from elasticsearch : %s",answer)
        return answer
    
    def get_answer_from_nlquepy(self):
        
        news = nlquepy.install("news")
        rule, answer, userdata = news.get_answer(self._question,None)
        logger.info("answer from nlquepy : %s",answer)
        return answer
             
def get_answer(question):
   
    response = Answer(question) 
    
    result = response.get_answer_from_nlquepy()
    
    if not result: 
        result = response.get_answer_from_elastic_search()
        
    if result :
        return result
    else :
        return ("I dont Know")
    
    

