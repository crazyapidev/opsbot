'''
Created on Feb 9, 2018

@author: 420169

'''
import json
import logging
from flask import make_response
from response_generator import get_response
logger = logging.getLogger(__name__)


def redirect_action_intent(query,intent):
    
    if intent == 'actions.intent.MAIN':
        result = "Virtual news anchor welcomes you to Agencia EFE news feed. What topic are you interested in today?"
    elif intent == 'actions.intent.CANCEL':
        result = "Ok let's try this again later"
    elif intent == 'actions.intent.NO_INPUT':
        result = "It seems you got struck"
    else :
        result = get_response(query)
    
    return result



def process_request(request_query):
    
    query = request_query["inputs"][0]["rawInputs"][0]["query"]
    intent = request_query["inputs"][0]["intent"]
    result = redirect_action_intent(query, intent)
    response = normalize_actions_response(result)
    return response



def normalize_actions_response(result):
    
    action_response =     {
                "conversation_token": "42",
                "expect_user_response": True,
                "expected_inputs": [
                {
                  "input_prompt": {
                    "initial_prompts": [
                      {
                        "ssml":"<speak>"+ result+"</speak>"
                      }
                    ],
                    "no_input_prompts": [
                      {
                        "text_to_speech": "I don't know."
                      },
                      {
                        "text_to_speech": "I don't have any information about it"
                      },
                      {
                        "text_to_speech": "We can stop here. Let's play again soon."
                      }
                    ]
                  }
                }
                ]
            }
    
    action_response = json.dumps(action_response, indent=4)
    logger.info("response : %s",action_response)
    action_response = make_response(action_response)
    action_response.headers['Content-Type'] = 'application/json' 
    return action_response
    

