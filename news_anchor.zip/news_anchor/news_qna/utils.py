'''
Created on Feb 9, 2018

@author: 420169
'''
import json

def get_context():
    with open('context.json',"r") as f:
        context = json.load(f)
    return context

def save_context(context):
    with open('context.json', 'w') as outfile:
        json.dump(context, outfile)
        
def valid_query(query):
    with open ('keywords.txt' , 'r') as f:
        keywords = f.read().split()
    word_list = query.split()
    Valid = False
    for word in word_list:
        if word.lower() in keywords: 
            Valid = True 
            break
    return Valid
