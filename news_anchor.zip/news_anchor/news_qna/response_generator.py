# -*- coding: utf-8 -*-
import sys 
import json 
import logging
from utils import get_context,save_context
from query_parser import IntentTagger

logger = logging.getLogger(__name__)
 

    
def tag_intent_entities(query):
    """
    classify intent and tag entities
    """
    query_parser = IntentTagger()
    query_parameters = query_parser.parse(query)
    return query_parameters

def get_response(query):
    
    query = query.lower().replace('ok google','')
    
    context = get_context()
    response = ''
    
    query_parameters = tag_intent_entities(query)
    
    if query_parameters["intent"]:
        context["intent"] = query_parameters["intent"]
    save_context(context)
    logger.info("user_question : %s",query_parameters)
    
    if context['intent'] == "search_articles":
        response = get_headlines_for_query(query)
    elif context['intent'] == "read_article":
        response = read_article(query,context)
    
    
    logger.info("response : %s",response)
    
    return response


def read_article(query,context):
    if not context["previous_response"]:
        
        response = "Spain forward Diego Costa on Thursday expressed his gratitude to Atletico Madrid's fans for voting him Player of the Month for January, after beginning his second spell at the La Liga club."+\
                "The 29-year-old has played six matches since he was registered as an Atleti player on Jan. 1, scoring three goals and assisting on two"+\
                "<break time='1s' /> Should I cast Diego Costa’s interview from EFE International Youtube channel on your living room TV?  "
        context["previous_response"] = response
    else:
        context["previous_response"] = ""
        response = ""
    save_context(context)
    
    return response
    
def get_headlines_for_query(query):
    
    response = "The latest headlines from Spanish Soccer are <break time='1s' />" + \
                "Spanish soccer club Malaga presents its 3 new signings <break time='1s' />"+\
                "Atletico's Player of the Month Diego Costa thanks fans for their vote <break time='1s' />"+\
                "Seedorf signs as coach of Spain's Deportivo <break time='1s' />"+\
                "Which article would you like me to read?"
    
    return response


# def get_response(query):
#     
#     query = query.lower().replace('ok google','')
#     
#     context = get_context()
#     response = ''
#     
#     query_parameters = tag_intent_entities(query)
#     logger.info("user_question : %s",query_parameters)
#     
#     if query_parameters["product_name"]:
#         context["product_name"] = query_parameters["product_name"]
#         #method to implement
#     if query_parameters["intent"]:
#         context["intent"] = query_parameters["intent"]
#     save_context(context)
#     
#     if not context["product_name"] :
#         response = ("Definitely . Please specify the product name")
#     else:
#         if context["intent"] == "product_information":
#             response = "yet to be implemented"#get_answer(query)
#         elif context["intent"] == "order":
#             if not context["previous_response"]:
#                 response = "Sure. I will add the product to your shopping cart.<break time='1s' />\n Can I take your shipping & credit card details from your Google account?"
#                 context["previous_response"] = response
#             else :
#                 context["previous_response"] = ""
#                 if query == "yes":
#                     response = "Congrats! Your order has been successfully placed. Item will be delivered in next 4 days"
#             save_context(context)
#         elif context["intent"] == "similar_products":
#             if not context["previous_response"]:
#                 response = "we have forte nonstick saute pan and  all-clad ns1 nonstick induction pan <break time='1s' />\n Do you want some more information related to these products?"
#                 context["previous_response"] = response
#             else :
#                 context["previous_response"] = ""
#                 if query == "no":
#                     response = ""
#             save_context(context)
#         elif context["intent"] == "clear":
#             context["product_name"] = ""
#             context["product"] = ""
#             context["intent"] = ""
#             save_context(context)
#             response = "Clearing previous product search criteria"
#     
#     logger.info("response : %s",response)
#     
#     return response
#     
