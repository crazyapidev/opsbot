
from elasticsearch import Elasticsearch

es_host = 'ec2-54-165-65-24.compute-1.amazonaws.com'
es_port = 80


                        
es = Elasticsearch(hosts=[{'host': es_host, 'port': int(es_port)}]) 