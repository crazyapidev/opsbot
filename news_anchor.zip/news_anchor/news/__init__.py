# -*- coding: utf-8 -*-
"""
Importing all pattern modules to match 

"""
from catalogue_rules import *