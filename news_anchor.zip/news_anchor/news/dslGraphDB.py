# -*- coding: utf-8 -*-
"""
domain specific language for custom GraphDB
"""

class NumberOfObjects():
    
    def __init__(self,tokens):
        self.field = tokens
    relation = "number Of Objects In Solar System"
    reverse = True
    
class Definition():
    
    def __init__(self,tokens):
        self.field = tokens 
    relation = "definition of Object"
    reverse = True
    
class NameOf():
    
    def __init__(self,tokens):
        self.field = tokens
    relation = "name Of objects In solar system"
    reverse = True
    
class ContentOf():
    def __init__(self):
        self.field = "Solar System"
    relation = "content of object"
    reverse = True