# -*- coding: utf-8 -*-
"""
query generation
"""
import re

class GenerateQuery():
    def generate_query(self,expression):
        pattern = re.compile("objects|object")
        query = re.sub(pattern,expression.field,expression.relation.lower())
        target = "data source"
        return target,query
        
