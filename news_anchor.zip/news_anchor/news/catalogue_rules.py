# -*- coding: utf-8 -*-
from __future__ import print_function
from rules import *
from refo import Group, Question,Star,Literal,Any
from elasticSearch.get_definition import *
from nltk.stem import PorterStemmer
import logging 
from news.rules import NNP
logger = logging.getLogger(__name__)


product_name = Plus(Pos("NN") | Pos("NNS") | Pos("NNP") | Pos("NNPS")|Pos("JJ")) 
    
class ProductPrice(QuestionTemplate):
    """
        price
        cost
        what is the price
        what is the price of product
        what is the price of this product
    """ 
    
    query_field = Lemma("price")|Lemma("cost")
    
    regex =  (Question(WHAT|HOW) + Question(BE))  + Question(DET) +  \
                query_field + Star(DET|PREP) + Question(product_name)
    
    def answer(self,match,context):
        rulename = self.__class__.__name__
        logger.debug("matched with regex: {}".format(rulename))
        logger.info("regex: %s",self.regex)
        answer = get_product_use("price")
        return answer,"price info"

"""
size
sizes
what is the size
what is the size|sizes of product
what is the size|sizes of this product
in which sizes is it available
in what sizes is the product available
in what sizes is it available
 """   
    
class ProductSize(QuestionTemplate):
    
    query_field = Lemma("size")|Lemma("sizes")
    available = Lemma("available")
    
    regex = Question(PREP) + (Question(WHAT|WHICH) + Question(BE))  + Question(DET) + Question(Any())+ query_field + \
        Star(DET|PREP|BE) + Question(object) + Question(product_name) + Question(available)
    
    def answer(self,match,context):
        rulename = self.__class__.__name__
        logger.debug("matched with regex: {}".format(rulename))
        logger.info("regex: %s",self.regex)
        answer = get_product_options("size")
        return answer,"size info"
    
"""
color
colors
what is the color
what is the color|colors of product
what is the color|colors of this product
in which color is it available
in what color is the product available
in what color is it available
 """   
    
class WhatIsColor(QuestionTemplate):
    
    query_field = Lemma("color")|Lemma("colors")
    option = Lemma("option")|Lemma("options")
    available = Lemma("available")
    
    regex = Question(PREP) + (Question(WHAT|WHICH|HOW) + Question(BE|ADJ))  + \
                Question(DET) + query_field + Star(DET|PREP|BE|Pos("PRP")) + \
                Question(option)+ Question(object) + Question(product_name) + Question(available)
    
    def answer(self,match,context):
        rulename = self.__class__.__name__
        logger.debug("matched with regex: {}".format(rulename))
        logger.info("regex: %s",self.regex)
        logger.info("query_field: %s","color")
        answer = get_product_options("color")
        return answer,"color info"
   

"""
use
what is the use
What is the use of this product?
what are the tip|tips|instruction|instructions to use this product
how do i use this product
 """   
    
class WhatIsUse(QuestionTemplate):
    
    tips = Lemma("tip")|Lemma("tips")|Lemma("instruction")|Lemma("instructions")
    query_field = Lemma("use")
    
    regex =  (Question(WHAT|HOW) + Question(BE))  + Question(DET) +  Star(Any()) + \
                 Question(tips) + Question(TO) + query_field + \
                Star(DET|PREP|BE) + Question(object) + Question(product_name)
    
    def answer(self,match,context):
        rulename = self.__class__.__name__
        logger.debug("matched with regex: {}".format(rulename))
        logger.info("regex: %s",self.regex)
        answer = get_product_use("use")
        return answer,"use info"

"""
care
what is the care
What is the care of this product?
How do i take care of this product
 """   
    
class WhatCare(QuestionTemplate):
    
    query_field = Group(Lemma("care"),"query_field" )
    
    regex =  (Question(WHAT|HOW) + Question(BE))  + Star(Any())  + \
                 query_field + Star(DET|PREP|BE)  + Question(product_name)
    
    def answer(self,match,context):
        rulename = self.__class__.__name__
        logger.debug("matched with regex: {}".format(rulename))
        logger.info("regex: %s",self.regex)
        answer = get_product_use("care")
        return answer,"care info"


    
class WhatIsShipping(QuestionTemplate):
    
    query_field = Group(Lemma("shipping")|Lemma("shipping policy")|Lemma("delivery")|Lemma("delivery policy"),"query_field" )
    
    regex =  (Question(WHAT) + Question(BE)) + Question(DET)  + query_field + \
                Star(DET|PREP|BE) + Question(product_name) + Question(VBP|VERB)
    
    def answer(self,match,context):
        rulename = self.__class__.__name__
        logger.debug("matched with regex: {}".format(rulename))
        logger.info("regex: %s",self.regex)
        answer = "UPS can deliver most in-stock items within 3-5 business days. The shipping rate varies depending on your order total and shipping destination"
        return answer,"usage info"


"""
rating
average rating
overall rating
"""    

class WhatIsAverageRating(QuestionTemplate):
    
    
    query_field = Lemma("rating")|Lemma("average rating")|Lemma("overall review")

    regex = (Question(WHAT) + Question(BE)) + Question(DET) + query_field 
    
    def answer(self,match,context):
        rulename = self.__class__.__name__
        logger.debug("matched with regex: {}".format(rulename))
        logger.info("regex: %s",self.regex)
        answer = "4.6 out of 5"#get_average_product_rating()
        return answer,"average review"   
    
"""
usage
what does this product do
"""   
    
class WhatUsage(QuestionTemplate):
    
    query_field = Lemma("usage")
    
    regex =  Question(WHAT) +Question(Any()) + Question(DET)  + Question(query_field) + \
            Star(DET|PREP|BE) + Question(object) + Question(product_name) + Question(VBP|VERB)
    
    def answer(self,match,context):
        rulename = self.__class__.__name__
        logger.debug("matched with regex: {}".format(rulename))
        logger.info("regex: %s",self.regex)
        answer = "Forte takes cookware to new heights of performance with a breakthrough in nonstick technology. The five-layer nonstick coating is exceptionally resistant to scratches and will last for years. Allowing minimal-oil cooking, this fry pan releases food easily, and is induction compatible and safe for use with metal utensils."
        return answer,"usage info"


    


