# -*- coding: utf-8 -*-
from nlquepy.parsing import Lemma,Pos,Token,Lemmas,Tokens,QuestionTemplate
from refo import Group, Plus, Question


thing = Group( Pos("NN") | Pos("NNS") | Pos("NNP") | Pos("NNPS") ,"thing")
object = Group( thing | Pos("JJ")| (thing | Pos("JJ")) + thing ,"object")
    

""" noun_forms"""
NN = Pos("NN") 
NNS  =  Pos("NNS")
NNP  = Pos("NNP")
NNPS = Pos("NNPS")

"""Question_forms"""
WHICH = Lemma("which")
WHEN = Lemma("when")
WHAT = Lemma("what")
HOW = Lemma("how")
WHY = Lemma("why")
WHO = Lemma('who')
   
""" verb_forms"""
BE = Lemma("be")                 # AUXILARY VERB
VBP = Pos("VBP")  
VBZ = Pos("VBZ")              
VERB = Pos("VB")            # VERB
VBD = Pos("VBD")                 # PAST TENSE
VBG = Pos("VBG")                 # VERB CONTINUOUS 
VBN =Pos("VBN")                  # PAST PARTCIPLE
    
""" noun_verb_modifers"""
ADVB                = Pos("RB")    # ADVERB
ADVBCOMP    = Pos("RBR")           # ADVERB COMPARATIVE
ADVBSUP    = Pos("RBS")            # ADVERB SUPERLATIVE
ADJ              = Pos("JJ")       # ADJECTIVE
ADJCOMP  = Pos("JJR")              # ADJECTIVE COMPARATIVE 
ADJSUP  = Pos("JJS")               # ADJECTIVE SUPERLATIVE
    
""" connecting_words"""
CC                     = Pos("CC")          # and,but,yet
PREP                   = Pos("IN")          #  preposition from,in,over,on,of
TO                     = Pos("TO")          # to
DET                    = Pos("DT")          # the
predeterminer          = Pos("PDT")    
    
""" Miscellaneous"""
LS     =  Lemma("list")   # List Object
NUM = Pos("CD")       # NUMBER
SYM = Pos("SYM")      #SYMBOL
FRNWD =Pos("FW")      #FORIEGN WORD
PRP = Pos("PRP")
    
"""
        Conjunction                               =          "CC" ,
        Number                                    =          "CD" ,
        Determiner                                =          "DT" ,
        Foreign_word                              =          "FW" ,
        Preposition                               =          "IN" ,
        Adjective                                 =          "JJ" ,
        Adjective_comparative                     =          "JJR",
        Adjective_superlative                     =          "JJS",
        List_item                                 =          "LS" ,
        Modal                                     =          "MD" ,
        Noun                                      =          "NN" ,
        Noun_plural                               =          "NNS",
        Proper_noun                               =          "NNP",
        Proper_noun_plural                        =          "NNPS",
        Predeterminer                             =          "PDT",
        Possessive_ending                         =          "POS",
        Personal_pronoun                          =          "PRP",
        Adverb                                    =          "RB" ,
        Adverb, comparative                       =          "RBR",
        Adverb, superlative                       =          "RBS",
        Particle                                  =          "RP" ,
        Symbol                                    =          "SYM",
        to                                        =          "TO" ,
        Interjection                              =          "UH" ,
        Verb                                      =          "VB" ,
        Verb_past                                 =          "VBD",
        Verb_present_participle                   =          "VBG",
        Verb_past_participle                      =          "VBN",
        Wh_determiner                             =          "WDT",
        Wh_pronoun                                =          "WP" ,
        Wh_adverb                                 =          "WRB"      
"""