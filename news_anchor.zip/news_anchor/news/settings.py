# coding: utf-8


"""
Settings.
"""

# Generated query language
LANGUAGE = "sparql"

# POS Tagger
TAGGER = 'NLTK'
# TAGGER = 'SPACY'

TOKENIZER = 'WHITE_SPACE_TOKENIZER'

# Tagger config
NLTK_DATA_PATH = ['/home/ubuntu/nltk_data','C:/nltk_data',"D:/nltk_data","/usr/local/share/nltk_data"]  # List of paths with NLTK data
SPACY_DATA_PATH = ["C:/Users/574967/Python27/Lib/site-packages/spacy/data/en-1.1.0"] # path for spacy tagger data



