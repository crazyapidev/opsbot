import operator

"""
Loading training & test data

dimension of word_vectors "50" ( from gensim) 
"""
def load_data(filename):
    res = []
    with open(filename, 'r') as f:
        for line in f:
            label, question = line.split(" ", 1)
            res.append((label, question))
    return res

"""
Converting word to vector using gensim Word2Vec/KeyedVec
Word projections(PCA(dimensionality reduction))
loading word vectors from gensim to create feature vectors for words in questions 
"""
vector_dim = 50

def average_vector2(dictionary, question):
    cnt = 0
    s = [0]*vector_dim
    for w in question.split(" "):
        w = w.lower()
        cnt += 1
        try:
            s = map(operator.add, dictionary[w], s)
        except KeyError:
            cnt -= 1
    if cnt == 0:
        return s
    return [elem/float(cnt) for elem in s]

def average_vector(dictionary, question):
    splitted = question.split(" ")
    s = [0]*vector_dim
    cnt = 2.0
    try:
        if (len(splitted) == 0):
            return s
        else:
            s = map(operator.add, dictionary[splitted[0].lower()], s)
            if (len(splitted) <= 1):
                return s
            s = map(operator.add, dictionary[splitted[1].lower()], s)
            if (splitted[0].lower() == 'what' and splitted[1].lower() == 'is'):
                return average_vector2(dictionary, question)
            return [elem/cnt for elem in s]         
    except KeyError:
        return s 

"""
compute accuracy
""" 
def compute_accuracy(predicted, original):
    eq = [z[0] == z[1] for z in zip(predicted, original)]
    return eq.count(True)/float(len(eq))

"""
export trained model
"""
def export_trained_model(classifier,model_path):
    import pickle
    pickle.dump(classifier, open(model_path, 'wb'))
    
    