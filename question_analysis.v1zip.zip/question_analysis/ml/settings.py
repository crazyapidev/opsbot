
"""
settings for train Question classifier model
"""
"""
choose Classifier
"""
classifier = "Logistic" # "RandomForest"

"""
Modeling for EntityType classifier
classes available 
['ABBR:abb', 'ABBR:exp', 'DESC:def', 'DESC:desc', 'DESC:manner', 'DESC:reason', 'ENTY:animal',
'ENTY:body', 'ENTY:color', 'ENTY:cremat', 'ENTY:currency', 'ENTY:dismed', 'ENTY:event', 'ENTY:food',
'ENTY:instru', 'ENTY:lang', 'ENTY:letter', 'ENTY:other', 'ENTY:plant', 'ENTY:product', 'ENTY:religion',
'ENTY:sport', 'ENTY:substance', 'ENTY:symbol', 'ENTY:techmeth', 'ENTY:termeq', 'ENTY:veh', 'ENTY:word',
'HUM:desc', 'HUM:gr', 'HUM:ind', 'HUM:title', 'LOC:city', 'LOC:country', 'LOC:mount', 'LOC:other',
'LOC:state', 'NUM:code', 'NUM:count', 'NUM:date', 'NUM:dist', 'NUM:money', 'NUM:ord', 'NUM:other',
'NUM:perc', 'NUM:period', 'NUM:speed', 'NUM:temp', 'NUM:volsize', 'NUM:weight']

"""

"""
prediction only entity type ( no of classes reduced)
['ABBR','DESC','ENTY','HUM','NUM','LOC']
"""
target_classes = "EntityType" # "EntityOnly"

"""
path to load gensim word vectors
"""
word_vector_path = "/Users/thrinadha/Documents/question&answerSystem/question-classification-master/glove.6B.50d.txt"
"""
paths for training and testing data
"""
training_data_path = "/Users/thrinadha/Documents/question&answerSystem/question-classification-master/data/train_5500.label"
testing_data_path = "/Users/thrinadha/Documents/question&answerSystem/question-classification-master/data/TREC_10.label"

"""
trained model path to store or to load
"""
model_path = "" 

