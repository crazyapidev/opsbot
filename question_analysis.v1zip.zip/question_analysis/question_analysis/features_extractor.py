"""
This module extracts the linguistic features that
will be input to question classifier.
Focus,named entities,SV
"""
