
import pickle
import numpy as np
from gensim.models import KeyedVectors 
from ml.utils import average_vector
from ml.settings import word_vector_path,model_path

word_vector = KeyedVectors.load_word2vec_format(word_vector_path, binary=False)

class QuestionClassifier():
    
    def __init__(self):
        self.modelpath = model_path
    
    def classify_question(self,query):
        return self.classifier.predict([np.asarray(average_vector(word_vector, query.lower()))])
        
    def load_model(self):
        self.classifier = pickle.load(open(self.model_path, 'rb'))